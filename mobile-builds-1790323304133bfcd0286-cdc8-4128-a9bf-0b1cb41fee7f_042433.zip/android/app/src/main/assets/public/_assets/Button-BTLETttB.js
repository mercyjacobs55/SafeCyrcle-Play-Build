import{R as d,j as l,aZ as u}from"./vendor-BeflnOI5.js";const q="_button_1a9tq_2",b="_sm_1a9tq_32",p="_md_1a9tq_38",y="_lg_1a9tq_44",g="_icon_1a9tq_52",$="_primary_1a9tq_97",f="_secondary_1a9tq_114",x="_destructive_1a9tq_132",R="_outline_1a9tq_156",h="_ghost_1a9tq_176",j="_link_1a9tq_193",k="_disabled_1a9tq_225",t={button:q,sm:b,md:p,lg:y,icon:g,"icon-md":"_icon-md_1a9tq_53","icon-sm":"_icon-sm_1a9tq_59","icon-lg":"_icon-lg_1a9tq_65",primary:$,secondary:f,destructive:x,outline:R,ghost:h,link:j,disabled:k},v=d.forwardRef(({children:s,variant:_="primary",size:n="md",asChild:a=!1,className:c,disabled:o,type:i="button",...e},r)=>{const m=a?u:"button";return l.jsx(m,{ref:r,type:i,className:`
        ${t.button} 
        ${t[_]} 
        ${t[n]} 
        ${o?t.disabled:""} 
        ${c||""}
      `,disabled:o,...e,children:s})});v.displayName="Button";export{v as B};
