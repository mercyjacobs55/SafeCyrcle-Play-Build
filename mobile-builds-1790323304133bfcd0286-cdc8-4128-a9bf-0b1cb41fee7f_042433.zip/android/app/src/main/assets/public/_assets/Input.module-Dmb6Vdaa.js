const t="_input_1pney_2",n={input:t};export{n as i};
