const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["_assets/web-B0AMtBt9.js","_assets/vendor-BeflnOI5.js"])))=>i.map(i=>d[i]);
import{v as e,_ as o}from"./vendor-BeflnOI5.js";const _=e("Browser",{web:()=>o(()=>import("./web-B0AMtBt9.js"),__vite__mapDeps([0,1])).then(r=>new r.BrowserWeb)});export{_ as Browser};
