const t="_page_d55v0_1",n="_content_d55v0_1",e={page:t,content:n};export{e as s};
